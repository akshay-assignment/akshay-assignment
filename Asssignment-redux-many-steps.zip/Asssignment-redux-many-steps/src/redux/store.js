import { createStore , combineReducers} from "redux";
import { movieReducer } from "./movie/reducers/movie.reducers";
import { heroReducer } from "./hero/reducers/hero.reducers";

const rootReducer = combineReducers({
    heroes : heroReducer,
    movies :movieReducer
})
const store = createStore(rootReducer);

export default store;
