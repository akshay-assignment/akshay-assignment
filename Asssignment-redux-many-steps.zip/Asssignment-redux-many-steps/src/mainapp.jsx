import  { Component } from "react";
import MovieComp from "./components/movie.component";
import HeroComp from "./components/hero.component";
import { Provider } from "react-redux";
import store from "./redux/store";
class MainApp extends Component{
    render(){
        return <div className="container">
                    <h1>React Redux</h1>
                    <hr/>
                    <Provider store={ store }>
                        <MovieComp/>
                        <HeroComp/>
                      
                    </Provider>
                </div>
    }
}

export default MainApp;