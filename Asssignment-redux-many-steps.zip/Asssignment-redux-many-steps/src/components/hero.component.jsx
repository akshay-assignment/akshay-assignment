
import { addHero, removeHero } from "../redux/index";
import { useDispatch, useSelector }from "react-redux";

let HeroComp =()=>{;

    let numOfHeroes = useSelector((state)=> state.heroes.numOfHeroes);
    let dispatch = useDispatch();
    return <div>
    <h2>Hero's count : { numOfHeroes } </h2>
    
    <button className="btn btn-primary" onClick={()=> dispatch(addHero())}>Add Hero</button>
    &nbsp;
    <button className="btn btn-warning" onClick={()=> dispatch(removeHero())}>Add Hero</button>
</div>
}
export default HeroComp;